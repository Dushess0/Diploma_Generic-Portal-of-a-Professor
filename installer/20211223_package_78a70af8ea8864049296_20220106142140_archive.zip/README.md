# Diploma_Generic Portal-of a Professor
 esign and Implementation of a Generic Portal of a University Professor
